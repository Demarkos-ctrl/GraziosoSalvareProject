public class Monkey extends RescueAnimal {
    // Monkey-specific attributes
    private float tailLength;
    private float height;
    private float bodyLength;
    private String species;

    // Default constructor
    public Monkey() {
        super();
    }

    // Detailed constructor
    public Monkey(String name, String animalType, String gender, String age, String weight, String acquisitionDate, String acquisitionLocation, String trainingStatus, boolean reserved, String inServiceCountry, float tailLength, float height, float bodyLength, String species) {
        super();
        setName(name);
        setAnimalType(animalType);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionLocation);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
        this.tailLength = tailLength;
        this.height = height;
        this.bodyLength = bodyLength;
        this.species = species;
    }

    // Accessor methods
    public float getTailLength() {
        return tailLength;
    }

    public void setTailLength(float tailLength) {
        this.tailLength = tailLength;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public float getBodyLength() {
        return bodyLength;
    }

    public void setBodyLength(float bodyLength) {
        this.bodyLength = bodyLength;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
}

