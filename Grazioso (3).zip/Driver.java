import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Example: Adding some initial data for testing
        dogList.add(new Dog("Max", "German Shepherd", "Male", "5", "30.0", "01-01-2020", "Germany", "in-service", false, "Germany"));
        
        while (true) {
            displayMenu();
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    intakeNewDog();
                    break;
                case "2":
                    intakeNewMonkey();
                    break;
                case "3":
                    reserveAnimal();
                    break;
                case "4":
                    printDogs();
                    break;
                case "5":
                    printMonkeys();
                    break;
                case "6":
                    printAnimals();
                    break;
                case "7":
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void displayMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Intake a new dog");
        System.out.println("2. Intake a new monkey");
        System.out.println("3. Reserve an animal");
        System.out.println("4. Print all dogs");
        System.out.println("5. Print all monkeys");
        System.out.println("6. Print all animals");
        System.out.println("7. Exit");
    }

    public static void intakeNewDog() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter breed: ");
        String breed = scanner.nextLine();
        System.out.print("Enter gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter age: ");
        String age = scanner.nextLine();
        System.out.print("Enter weight: ");
        String weight = scanner.nextLine();
        System.out.print("Enter acquisition date: ");
        String acquisitionDate = scanner.nextLine();
        System.out.print("Enter acquisition location: ");
        String acquisitionLocation = scanner.nextLine();
        System.out.print("Enter training status: ");
        String trainingStatus = scanner.nextLine();
        System.out.print("Is the dog reserved? (true/false): ");
        boolean reserved = Boolean.parseBoolean(scanner.nextLine());
        System.out.print("Enter in-service country: ");
        String inServiceCountry = scanner.nextLine();

        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reserved, inServiceCountry);
        dogList.add(newDog);

        System.out.println("New dog intake complete.");
    }

    public static void intakeNewMonkey() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter age: ");
        String age = scanner.nextLine();
        System.out.print("Enter weight: ");
        String weight = scanner.nextLine();
        System.out.print("Enter acquisition date: ");
        String acquisitionDate = scanner.nextLine();
        System.out.print("Enter acquisition location: ");
        String acquisitionLocation = scanner.nextLine();
        System.out.print("Enter training status: ");
        String trainingStatus = scanner.nextLine();
        System.out.print("Is the monkey reserved? (true/false): ");
        boolean reserved = Boolean.parseBoolean(scanner.nextLine());
        System.out.print("Enter in-service country: ");
        String inServiceCountry = scanner.nextLine();
        System.out.print("Enter tail length: ");
        float tailLength = Float.parseFloat(scanner.nextLine());
        System.out.print("Enter height: ");
        float height = Float.parseFloat(scanner.nextLine());
        System.out.print("Enter body length: ");
        float bodyLength = Float.parseFloat(scanner.nextLine());
        System.out.print("Enter species: ");
        String species = scanner.nextLine();

        Monkey newMonkey = new Monkey(name, "Monkey", gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reserved, inServiceCountry, tailLength, height, bodyLength, species);
        monkeyList.add(newMonkey);

        System.out.println("New monkey intake complete.");
    }

    public static void reserveAnimal() {
        System.out.print("Enter animal type (dog/monkey): ");
        String animalType = scanner.nextLine().toLowerCase();
        System.out.print("Enter country: ");
        String country = scanner.nextLine();

        boolean found = false;
        if (animalType.equals("dog")) {
            for (Dog dog : dogList) {
                System.out.println("Checking dog: " + dog.getName() + " in " + dog.getInServiceLocation() + " - Reserved: " + dog.getReserved()); // Debug statement
                if (dog.getInServiceLocation().equalsIgnoreCase(country) && !dog.getReserved()) {
                    dog.setReserved(true);
                    System.out.println("Dog reserved successfully.");
                    found = true;
                    break;
                }
            }
        } else if (animalType.equals("monkey")) {
            for (Monkey monkey : monkeyList) {
                System.out.println("Checking monkey: " + monkey.getName() + " in " + monkey.getInServiceLocation() + " - Reserved: " + monkey.getReserved()); // Debug statement
                if (monkey.getInServiceLocation().equalsIgnoreCase(country) && !monkey.getReserved()) {
                    monkey.setReserved(true);
                    System.out.println("Monkey reserved successfully.");
                    found = true;
                    break;
                }
            }
        }

        if (!found) {
            System.out.println("No available " + animalType + " found in " + country + ".");
        }
    }

    public static void printDogs() {
        System.out.println("List of Dogs:");
        for (Dog dog : dogList) {
            System.out.println(dog.getName() + " - " + dog.getBreed() + " - " + dog.getInServiceLocation() + " - Reserved: " + dog.getReserved());
        }
    }

    public static void printMonkeys() {
        System.out.println("List of Monkeys:");
        for (Monkey monkey : monkeyList) {
            System.out.println(monkey.getName() + " - " + monkey.getSpecies() + " - " + monkey.getInServiceLocation() + " - Reserved: " + monkey.getReserved());
        }
    }

    public static void printAnimals() {
        System.out.println("List of Dogs:");
        for (Dog dog : dogList) {
            System.out.println(dog.getName() + " - " + dog.getBreed() + " - " + dog.getInServiceLocation() + " - Reserved: " + dog.getReserved());
        }
        System.out.println("List of Monkeys:");
        for (Monkey monkey : monkeyList) {
            System.out.println(monkey.getName() + " - " + monkey.getSpecies() + " - " + monkey.getInServiceLocation() + " - Reserved: " + monkey.getReserved());
        }
    }
}
